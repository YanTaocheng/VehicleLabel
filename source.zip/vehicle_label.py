# _*_ coding:utf-8 _*_
__anthor__ = "yan"

from tkinter import *
from tkinter import ttk
import re
import threading
import xmltodict

def parse_xml(xml_file="VehicleLabelConfig.xml"):
    xml=open(xml_file,"r")
    xml_string=xml.read()
    xml.close()
    return xmltodict.parse(xml_string)

def write_xml(xml_dic, xml_file="VehicleLabelConfig.xml"):
    xml_string=xmltodict.unparse(xml_dic, pretty=True)
    out_xml=open(xml_file,"w")
    out_xml.write(xml_string)
    out_xml.close()

def load_content(path, line):
#返回值为path文件第line行的名词，格式为string

    file = open(path, "rb")
    content = file.readlines()
    if line == len(content):
        content = content[int(line)-1].decode()
    else:
        content = content[int(line)-1][:-2].decode()
    file.close()
    
    return content
    
def content_lines(path):
#返回值为path文件行数，格式为Int

    file = open(path, "rb")
    content = file.readlines()
    file.close()
    return len(content)

def search(path, search_word):
#返回值为path路径文件中含search_word的行的列表，格式为list
    file = open(path, "rb")
    content = file.readlines()
    lines = len(content)
    search_result = []
    
    for i in range(0,lines):
        content_ = content[i].decode()
        if re.search(search_word, content_[0:12]):
            search_result.append(content_)
            
    file.close()
    return search_result
    
def delete(path, line):
#删除path文件第line行的字符串
    file = open(path, "r+",encoding='UTF-8')
    content = file.readlines()
    #print(len(content))
    if line == len(content):
        content[int(line)-1] = ""
    else:
        content[int(line)-1] = "\n"
    file.seek(0)
    file.truncate()
    for i in content:
        file.write(i)
    file.close()

class MainPage(object):
    def __init__(self):
        self.root = Tk()
        self.root.title('车辆名词标注')
        ws = self.root.winfo_screenwidth() #获取桌面长度
        hs = self.root.winfo_screenheight() #获取桌面高度
        self.root.geometry('1100x650+%d+%d'%(ws/2-500,hs/2-300))  # 设置窗口大小
        self.config = parse_xml()

        self.page_skip()

    def page_skip(self):
        self.root.resizable(0,0)
        
        #We are creating a container in tab to hold Page Skip widgets
        page_skip = ttk.LabelFrame(self.root)
        page_skip.grid(column=0, row=0, columnspan=2, padx=10, pady=1, sticky='W')

        #Page label,enter
        self.tab1_page = StringVar()
        ttk.Label(page_skip, text="行数:").grid(column=0, row=0, sticky='W')
        self.page_enter = ttk.Entry(page_skip, width=8, textvariable=self.tab1_page)
        self.page_enter.grid(column=1, row=0, sticky='W')
        
        #Skip button
        ttk.Button(page_skip, width=8, text='跳转', command=lambda: self.thread_it(self.skip_button)).grid(column=2, row=0, padx=10, sticky='W')
        #Last Page button
        ttk.Button(page_skip, width=8, text='上页', command=lambda: self.thread_it(self.last_button)).grid(column=3, row=0, sticky='W')
        #Next Page button
        ttk.Button(page_skip, width=8, text='下页', command=lambda: self.thread_it(self.next_button)).grid(column=4, row=0, sticky='W')
        
        ttk.Label(page_skip, text="标注文件地址:").grid(column=5, row=0, sticky='W')
        self.path1 = StringVar()
        self.path1_enter = ttk.Entry(page_skip, width=35, textvariable=self.path1)
        self.path1_enter.grid(column=6, row=0, sticky='W') 
        self.path1.set(r"5gram.txt")
        
        ttk.Label(page_skip, text="Sample文件地址:").grid(column=7, row=0, sticky='W')
        self.path2 = StringVar()
        self.path2_enter = ttk.Entry(page_skip, width=35, textvariable=self.path2)
        self.path2_enter.grid(column=8, row=0, sticky='W')
        self.path2.set(r"samples.json")
        
        try:
            self.tab1_page.set(self.config["Config"]["Line"])
            self.path1.set(self.config["Config"]["LabelFilePath"])
            self.path2.set(self.config["Config"]["SampleFilePath"])
        except:
            pass
            
    def content_page(self, line):
        content_page_ = ttk.LabelFrame(self.root)
        content_page_.grid(column=0, row=1, padx=10, pady=1, sticky='W')
        style = ttk.Style()
        style.configure('BW.TLabel', foreground="blue")
        
        #----content lines----
        for m in range(0,5):
            for i in range(20*m,20+20*m):
                current_line = line+i
                current_content = load_content(self.path1_enter.get(), current_line)
                line_label = ttk.Label(content_page_, text=str(current_line), relief=SUNKEN, anchor=CENTER, width=6)
                line_label.grid(column=m*3, row=i-20*m, pady=3) 
                
                content_button = Button(content_page_, text=current_content, width=10, bd=0, command=lambda current_line=current_line:self.copy_line(current_line))
                content_button.grid(column=m*3+1, row=i-20*m)
                
                sv = ttk.Separator(content_page_, orient=VERTICAL)
                sv.grid(row=0,column=m*3+2,rowspan=20,sticky="ns",padx=8)
                
    def edit_page(self):
        edit_page_ = ttk.LabelFrame(self.root)
        edit_page_.grid(column=1, row=1, padx=10, pady=1, sticky='W')
        
        #edit line number
        edit_label = ttk.Label(edit_page_, text="编辑的行数:")
        edit_label.grid(column=0, row=0, sticky='w')
        self.edit_line = StringVar()
        self.edit_line_enter = ttk.Entry(edit_page_, width=15, textvariable=self.edit_line)
        self.edit_line_enter.grid(column=0, row=1, sticky='W')
        
        #detail text
        ttk.Button(edit_page_, width=18, text='显示Sample中例句', command=self.show_sample).grid(column=0, row=2, pady=5,sticky='W')
        self.sample_text = Text(edit_page_, width=35, height=15)
        self.sample_text.grid(column=0, row=3, sticky='W')
        self.sample_text.insert(1.0, "")
        
        ttk.Button(edit_page_, width=8, text='删除', command=self.delete_item).grid(column=0, row=5, pady=5, sticky='W')
        ttk.Button(edit_page_, width=8, text='不确定', command=self.not_sure).grid(column=0, row=6, pady=5, sticky='W')
        ttk.Button(edit_page_, width=8, text='车开头', command=self.start_with_vehicle).grid(column=0, row=7, pady=5, sticky='W')
        
    def show_sample(self):
        line = self.edit_line_enter.get()
        path1 = self.path1_enter.get()
        path2 = self.path2_enter.get()
        content = load_content(path1, line)
        
        if content != "":
            #text显示content在sample中详细内容
            sample = search(path2, content)[0]
            self.sample_text.delete(1.0, "end")
            self.sample_text.insert(1.0, sample)
            
            #在text显示的字符串中找出content，并标记
            position = 0
            for i in range(6,len(sample)):
                if re.search(content, sample[i:i+len(content)]):
                    position = i
                    #print(position)
                    break
            self.sample_text.tag_add("tag1", "1.%d"%position, "1.%d"%(position+len(content)))
            self.sample_text.tag_config("tag1", background="red", foreground="white")
        else:
            self.sample_text.delete(1.0, "end")
        
        
        
    def delete_item(self):
        line = self.edit_line_enter.get()
        path1 = self.path1_enter.get()
        content = load_content(path1, line)       
        if content != "":
            delete(path1, line)
            self.content_page(int(self.page_enter.get()))
            
            path = self.config["Config"]["OutputPath"]["Delete"]
            file = open(path,"a")
            file.write(line+" "+content+"\n")
            file.close()
        
    def not_sure(self):
        line = self.edit_line_enter.get()
        path1 = self.path1_enter.get()
        content = load_content(path1, line)
        if content != "":
            delete(path1, line)
            self.content_page(int(self.page_enter.get()))
            
            path = self.config["Config"]["OutputPath"]["NotSure"]
            file = open(path,"a")
            file.write(line+" "+content+"\n")
            file.close()
        
    def start_with_vehicle(self):
        line = self.edit_line_enter.get()
        path1 = self.path1_enter.get()
        content = load_content(path1, line)
        if content != "":
            delete(path1, line)
            self.content_page(int(self.page_enter.get()))
            
            path = self.config["Config"]["OutputPath"]["StartWithVehicle"]
            file = open(path,"a")
            file.write(line+" "+content+"\n")
            file.close()
        
    def skip_button(self):
        line = int(self.page_enter.get())
        lines = content_lines(self.path1_enter.get())-99
        if line <= 1:
            line = 1
        elif line > lines:
            line = lines
        self.tab1_page.set(line)
        self.content_page(line)   
        self.edit_page()
        
        self.config["Config"]["Line"] = line
        self.config["Config"]["LabelFilePath"] = self.path1_enter.get()
        self.config["Config"]["SampleFilePath"] = self.path2_enter.get()
        write_xml(self.config)
        
    def last_button(self):
        line = int(self.page_enter.get())-100
        if line <= 1:
            line = 1
        self.tab1_page.set(line)
        self.content_page(line)
        
        self.config["Config"]["Line"] = line
        self.config["Config"]["LabelFilePath"] = self.path1_enter.get()
        self.config["Config"]["SampleFilePath"] = self.path2_enter.get()
        write_xml(self.config)
        
    def next_button(self):
        line = int(self.page_enter.get())+100
        lines = content_lines(self.path1_enter.get())-99
        if line>lines:
            line = lines
        self.tab1_page.set(line)
        self.content_page(line)
        
        self.config["Config"]["Line"] = line
        self.config["Config"]["LabelFilePath"] = self.path1_enter.get()
        self.config["Config"]["SampleFilePath"] = self.path2_enter.get()
        write_xml(self.config)
        
    def copy_line(self,line):
        self.edit_line.set(line)
        self.show_sample()
        
    @staticmethod
    def thread_it(func):
        t = threading.Thread(target=func) 
        t.setDaemon(True)   # 守护--就算主界面关闭，线程也会留守后台运行（不对!）
        t.start()           # 启动
      
if __name__ == '__main__':
    app = MainPage()
    mainloop()
